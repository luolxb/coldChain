package com.soubao.jobhandler;

import com.baomidou.jobs.api.JobsResponse;
import com.baomidou.jobs.exception.JobsException;
import com.baomidou.jobs.handler.IJobsHandler;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.soubao.common.constant.OrderConstant;
import com.soubao.entity.Order;
import com.soubao.service.MallService;
import com.soubao.service.OrderService;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AutoReceiveJob implements IJobsHandler {
    @Autowired
    private OrderService orderService;
    @Autowired
    private MallService mallService;
    @Autowired
    private AmqpTemplate rabbitTemplate;

    /**
     * 每小时执行一次
     * 自动收货确认
     */
    @Override
    public JobsResponse execute(String tenantId, String param) throws JobsException {
        String date = (String) mallService.config().getOrDefault("shopping_auto_confirm_date", "7");
        List<Order> orders = orderService.list(new QueryWrapper<Order>().eq("order_status", 1)
                .eq("shipping_status", 1).apply("shipping_time < UNIX_TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL " + date + " DAY))"));
        if (orders.size() > 0) {
            for (Order order : orders) {
                order.setOrderStatus(OrderConstant.DELIVERY);
                order.setConfirmTime(System.currentTimeMillis() / 1000);
            }
            orderService.updateBatchById(orders);
            rabbitTemplate.convertAndSend("receive_order", "", orders);
        }
        return JobsResponse.ok();
    }
}
