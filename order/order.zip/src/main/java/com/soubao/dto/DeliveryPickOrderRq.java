package com.soubao.dto;

import com.soubao.entity.PickOrder;
import lombok.Data;

import java.util.List;

/**
 * 提货订单发货请求实体类
 */
@Data
public class DeliveryPickOrderRq {

    private Integer storeAddressId;
    private String note;
    private String invoiceNo;
    private List<PickOrder> pickOrderList;
}
