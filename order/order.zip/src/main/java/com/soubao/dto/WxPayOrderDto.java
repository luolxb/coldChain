package com.soubao.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Setter
@Getter
public class WxPayOrderDto {
    @NotNull
    private String orderSn;
    private String openid;
    private double amount;
    private String body;
    private String tradeType;//JSAPI,
    private String clientIp;
}
