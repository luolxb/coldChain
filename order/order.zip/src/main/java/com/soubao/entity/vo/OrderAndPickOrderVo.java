package com.soubao.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderAndPickOrderVo implements Serializable {

  //"订单ID")
    private Integer orderId;

  //"提货订单ID")
    private Integer pickOrderId;

  //"商品图片")
    private String originalImg;

  //"商品ID")
    private Integer goodsId;

  //"订单状态")
    private Integer orderStatus;

  //"订单状态描述")
    private String orderStatusDsc;

  //"提货订单状态")
    private Integer pickOrderStatus;

  //"下单时间")
    private int addTime;

  //"商品价格")
    private BigDecimal goodsPrice;

  //"商店名称")
    private String storeName;

  //"商店ID")
    private String storeId;

  //"商品名称")
    private String goodsName;

    /**
     * pickOrderStatus : 提货订单状态（0：待发货/提货中 1:确认发货 2：已发货/提货中 3：已完成/已提货）
     * payStatus 订单支付状态 0待支付 1已支付 5已取消订单
     *
     * @param orderStatus
     * @param pickOrderStatus
     * @return
     */
    public String getOrderStatusDsc(int orderStatus, Integer pickOrderStatus) {
        if (orderStatus == 1) {
            switch (pickOrderStatus) {
                case 0:
                    orderStatusDsc = "待发货";
                    break;
                case 1:
                    orderStatusDsc = "确认发货";
                    break;
                case 2:
                    orderStatusDsc = "待收货";
                    break;
                case 3:
                    orderStatusDsc = "已完成";
                    break;
            }
        }

        if (pickOrderStatus == null) {
            switch (orderStatus) {
                case 0:
                    orderStatusDsc = "代付款";
                    break;
                case 1:
                    orderStatusDsc = "已付款";
                    break;
                case 5:
                    orderStatusDsc = "已取消";
                    break;
            }
        }
        return orderStatusDsc;

    }


    private static final long serialVersionUID = 1L;


}
