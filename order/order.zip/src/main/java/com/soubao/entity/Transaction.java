package com.soubao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.sf.jsqlparser.expression.DateTimeLiteralExpression;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("`transaction`")
public class Transaction {

  //value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

  //value = "商品ID")
    private Integer goodsId;

  //value = "买家用户者ID")
    private Integer buyerId;

  //value = "卖家用户者ID")
    private Integer sellerId;

  //value = "订单ID")
    private Integer orderId;

  //value = "购买时间")
    private long purchaseTime;

  //value = "状态：0代表未支付，1代表已支付，2代表取消")
    private byte status;
}
