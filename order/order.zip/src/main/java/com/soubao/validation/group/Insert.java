package com.soubao.validation.group;

/**
 * 验证分组：插入场景
 */
public interface Insert {
}
