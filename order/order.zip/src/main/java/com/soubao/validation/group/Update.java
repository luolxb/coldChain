package com.soubao.validation.group;

/**
 * 验证分组：更新场景
 */
public interface Update {
}
