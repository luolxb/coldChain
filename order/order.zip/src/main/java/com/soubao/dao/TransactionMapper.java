package com.soubao.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.soubao.entity.Transaction;
public interface TransactionMapper extends BaseMapper<Transaction> {

}
