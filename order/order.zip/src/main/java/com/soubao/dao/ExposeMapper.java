package com.soubao.dao;

import com.soubao.entity.Expose;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 举报表 Mapper 接口
 * </p>
 *
 * @author dyr
 * @since 2020-03-02
 */
public interface ExposeMapper extends BaseMapper<Expose> {

}
