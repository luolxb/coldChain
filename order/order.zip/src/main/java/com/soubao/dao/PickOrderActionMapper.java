package com.soubao.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.soubao.entity.PickOrderAction;

public interface PickOrderActionMapper extends BaseMapper<PickOrderAction> {
}
