package com.soubao.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrderStatistics {
    private Integer waitPayCount; //待付款数量，不包括虚拟订单
    private Integer waitSendCount;//待发货数量
    private Integer waitReceiveCount;//待收货数量
    private Integer waitCommentCount;//待评论数量
    private Integer returnGoodsCount; //退换货数量
}
