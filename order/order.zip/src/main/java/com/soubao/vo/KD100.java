package com.soubao.vo;

import lombok.Data;

@Data
public class KD100 {
    private String com;
    private String num;
    private String phone;
    private Integer resultv2;
}
