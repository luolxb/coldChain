package com.soubao.service;

import com.soubao.entity.Expose;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 举报表 服务类
 * </p>
 *
 * @author dyr
 * @since 2020-03-02
 */
public interface ExposeService extends IService<Expose> {

}
