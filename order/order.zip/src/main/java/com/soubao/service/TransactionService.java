package com.soubao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.soubao.entity.Comment;
import com.soubao.entity.Transaction;
import org.springframework.stereotype.Service;


public interface TransactionService extends IService<Transaction> {
}
