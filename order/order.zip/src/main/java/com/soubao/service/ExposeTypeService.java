package com.soubao.service;

import com.soubao.entity.ExposeType;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 举报类型表 服务类
 * </p>
 *
 * @author dyr
 * @since 2020-03-02
 */
public interface ExposeTypeService extends IService<ExposeType> {

}
