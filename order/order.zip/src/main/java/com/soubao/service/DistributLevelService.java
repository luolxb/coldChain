package com.soubao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.soubao.entity.DistributLevel;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dyr
 * @since 2019-12-27
 */
public interface DistributLevelService extends IService<DistributLevel> {

}
