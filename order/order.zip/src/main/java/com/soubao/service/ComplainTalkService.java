package com.soubao.service;

import com.soubao.entity.ComplainTalk;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 投诉对话表 服务类
 * </p>
 *
 * @author dyr
 * @since 2020-02-29
 */
public interface ComplainTalkService extends IService<ComplainTalk> {

}
