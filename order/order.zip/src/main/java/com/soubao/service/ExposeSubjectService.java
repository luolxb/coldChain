package com.soubao.service;

import com.soubao.entity.ExposeSubject;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 举报主题表 服务类
 * </p>
 *
 * @author dyr
 * @since 2020-03-02
 */
public interface ExposeSubjectService extends IService<ExposeSubject> {

}
