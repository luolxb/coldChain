package com.soubao.service;

import com.soubao.entity.MiniappConfig;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dyr
 * @since 2020-05-07
 */
public interface MiniappConfigService extends IService<MiniappConfig> {

}
