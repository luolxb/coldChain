package com.soubao.service;

import com.soubao.entity.Reply;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dyr
 * @since 2020-04-21
 */
public interface ReplyService extends IService<Reply> {

}
