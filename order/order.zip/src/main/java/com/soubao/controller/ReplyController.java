package com.soubao.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dyr
 * @since 2020-04-21
 */
@RestController
@RequestMapping("/reply")
public class ReplyController {

}
